﻿using System;
using Xunit;
using EmpMgt_BAL.Service;
using EmpMgt_DAL.Models;
using EmpMgt_DAL.Interface;
using Moq;
using EmpMgt_BAL.Interface;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace XUnitEmpMgt201
{
   public class EmployeeServicexUnitTest
    {

        private readonly EmployeeService _empservicer_sut;
        private readonly Mock<IEmployeeData> _empdatamock = new Mock<IEmployeeData>();

        public EmployeeServicexUnitTest()
        {
            _empservicer_sut = new EmployeeService(_empdatamock.Object);
        }



        private static List<Employee> GetListOfEmployee()
        {
            var employee = new List<Employee>
            {
                new Employee(),
                new Employee()
            };
            return employee;
        }


        [Fact]
        public void GetAllEmployee_ReturnsListOfEmployeeEntities_Test()
        {
            // Arrange
            var employee = GetListOfEmployee();
            _empdatamock.Setup(p => p.GetEmployees()).Returns(employee);
            var service = new EmployeeService(_empdatamock.Object);

            // Act
            var result = service.GetAllEmployee().ToList();

            // Assert
            Assert.True(result.Any());
            Assert.Equal(employee.Count, result.Count());
            
        }

        private static Employee CreateDefaultEmployeeObject()
        {
            var Employee = new Employee
            {
               Id= Guid.NewGuid(),
                Name = "testEmployee1",
                Competency = "C3"
            };
            return Employee;
        }

        [Fact]
        public void GetEmployeebyId_ReturnsEmployeeEntity_Test()
        {
            // Arrange
            var Employee = CreateDefaultEmployeeObject();
            _empdatamock.Setup(m => m.GetEmployee(Employee.Id)).Returns(Employee);
            var service = new EmployeeService(_empdatamock.Object);

            // Act
            var result = service.GetEmployeeById(Employee.Id);

            // Assert

            Assert.NotNull(result);
            Assert.IsType<Employee>(result);
            Assert.Equal(Employee.Id, result.Id);
            Assert.Equal(Employee.Name, result.Name);
            Assert.Equal(Employee.Competency, result.Competency);
        }

      

        [Fact]
        public void GetEmployeebyId_CannotFindEmployee_ReturnsNullAsResult_Test()
        {
            // Arrange
        
            _empdatamock.Setup(m => m.GetEmployee(It.IsAny<Guid>())).Returns(valueFunction: () => null);
            var service = new EmployeeService(_empdatamock.Object);

            // Act
            var result = service.GetEmployeeById(It.IsAny<Guid>());

            // Assert
            Assert.Null(result);
           
        }

      
        [Fact]
        public void Delete_ShouldCallRepositoryDeleteOnce_Test()
        {
            // Arrange
            var Employee = CreateDefaultEmployeeObject();
            _empdatamock.Setup(m => m.GetEmployee(Employee.Id)).Returns(Employee);
            _empdatamock.Setup(m => m.DeleteEmployee(Employee)).Verifiable();
              
            var service = new EmployeeService(_empdatamock.Object);

            // Act
            service.DeleteEmployee(Employee.Id);

            // Assert
            _empdatamock.Verify(m => m.DeleteEmployee(It.Is<Employee>(p => p == Employee)), Times.Once());
        }

        [Fact]
        public void Create_ShouldCallRepositoryCreateOnce_Test()
        {
            // Arrange
            var Employee = CreateDefaultEmployeeObject();
            _empdatamock.Setup(m => m.AddEmployee(It.Is<Employee>(p => p == Employee)))
                .Verifiable();
            var service = new EmployeeService(_empdatamock.Object);

            // Act
            service.AddEmployee(Employee);

            // Assert
            _empdatamock.Verify(m => m.AddEmployee(It.Is<Employee>(p => p == Employee)), Times.Once());
        }











    }
}
