﻿namespace EmpMgt_StubEntities
{
    public class CommonStubEntity
    {
        public int Id { get; set; }
    }
}
