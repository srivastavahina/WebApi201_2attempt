﻿using EmpMgt_BAL.Interface;
using EmpMgt_DAL.Interface;
using EmpMgt_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmpMgt_BAL.Service
{
   public class EmployeeService :IEmployeeservice
    {
        private readonly IEmployeeData _employee;

        public EmployeeService(IEmployeeData employee)
        {
            _employee = employee;
        }



        public Employee GetEmployeeById(Guid UserId)
        {
            try
            {
                return _employee.GetEmployee(UserId);
            }
            catch (Exception)
            {
                throw;
            }
        }
       
        public List<Employee> GetAllEmployee()
        {
            try
            {
                return _employee.GetEmployees().ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
 
        public  Employee AddEmployee(Employee Employee)
        {
            try
            {
                return _employee.AddEmployee(Employee);
            }
            catch (Exception)
            { 
                throw; 
            }
        }
 
        public bool DeleteEmployee(Guid guid)
        {

            try
            {
                var DataList = _employee.GetEmployee(guid);
               
                    _employee.DeleteEmployee(DataList);
                
                return true;
            }
            catch (Exception)
            {
                throw;
            }

        }





    }
}
