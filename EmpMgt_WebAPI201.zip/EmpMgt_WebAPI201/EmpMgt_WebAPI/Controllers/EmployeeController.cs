﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmpMgt_BAL.Interface;

namespace EmpMgt_WebAPI.Controllers
{
    
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeservice _employeeService;
        public EmployeeController(IEmployeeservice employeeservice)
        {
            _employeeService = employeeservice;
        }

        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetEmployee(Guid id)
        {

            try
            {
                if (id == null)
                {
                    return BadRequest();
                }
                else
                {
                    var emp = _employeeService.GetEmployeeById(id);
                    if (emp != null)
                        return Ok(emp);
                    else
                    {
                        return NotFound();
                    }

                }
            }

            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }
    }


}
