using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmpMgt_DAL.Models;
using EmpMgt_DAL.Interface;
using EmpMgt_DAL.Data;
using EmpMgt_BAL.Service;
using EmpMgt_BAL.Interface;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using EmpMgt_DAL.Repository;

namespace EmpMgt_WebAPI201
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddDbContextPool<ApplicationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("EmployeeContextConnectionString")));
            services.AddTransient<RepositoryEmployee, RepositoryEmployee>();
            services.AddTransient<EmployeeService, EmployeeService>();
            services.AddTransient<IEmployeeservice, EmployeeService>();
            services.AddScoped<IEmployeeData, RepositoryEmployee>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
